/* -*-  Mode: C++; c-file-style: "gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2018 5GIC, University of Surrey
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: Ioannis Selinis <selinis.g@gmail.com>
 */
 
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/applications-module.h"
#include "ns3/mobility-module.h"
#include "ns3/random-variable-stream.h"
#include "ns3/wifi-module.h"
#include "ns3/internet-module.h"
#include "ns3/propagation-loss-model.h"
#include "ns3/ipv4-static-routing-helper.h"
#include "ns3/ipv4-list-routing-helper.h"
#include <ns3/yans-wifi-phy.h>
#include "ns3/boolean.h"
#include <chrono>

#include <string>
#include <iostream>
#include <fstream>



using namespace ns3;
using namespace std::chrono;

NS_LOG_COMPONENT_DEFINE ("tgax-collaboration");

std::ofstream *outfileAps;
std::ofstream *outfileStas;
std::ofstream *commonCompl;
std::ofstream *assFile;

std::vector<uint32_t> bytesTotalPerAp;
std::vector<uint32_t> bytesTotalPerSta;
std::vector<uint32_t> bytesTotalPerApTx;
std::vector<uint32_t> bytesTotalPerStaTx;

NodeContainer wifiStaNode, wifiApNode;
PacketSocketHelper packetSocket;
NetDeviceContainer staDevs, apDevs;

uint32_t StasNo;
uint32_t ApsNo;
uint32_t payloadSize;
double simulationTime;

uint32_t transmissionsCnt;
uint32_t colCntSta;

uint64_t generationRate;
unsigned int rate;

uint32_t totalStasToAss;

high_resolution_clock::time_point t1;

bool disableSnr;

void BeaconStarter (Ptr<WifiMac> mac)
{
	mac->SetAttribute("BeaconGeneration", BooleanValue (false/*true*/));
}

void ActivateSta (Ptr<WifiPhy> phySta, uint8_t channelId)
{
	phySta->SetAttribute("ChannelNumber", UintegerValue (channelId));
}

void SelectSrcDestForAp (Ptr<Node> ap, Ptr<NetDevice> apDev, Ptr<Node> sta, Ptr<NetDevice> staDev)
{
  double appStart = 10.0;  
  
  //DL
  PacketSocketAddress socket;
  socket.SetSingleDevice (apDev->GetIfIndex ());
  socket.SetPhysicalAddress (staDev->GetAddress ());
  socket.SetProtocol (1);
  OnOffHelper onoff ("ns3::PacketSocketFactory", Address (socket));

  onoff.SetAttribute("OnTime", StringValue ("ns3::ConstantRandomVariable[Constant=1000]"));
  onoff.SetAttribute("OffTime", StringValue ("ns3::ConstantRandomVariable[Constant=0]"));
  onoff.SetConstantRate (DataRate(generationRate));
  onoff.SetAttribute ("PacketSize", UintegerValue (payloadSize));

  ApplicationContainer apps = onoff.Install (ap);
  Ptr<UniformRandomVariable> trafficStart = CreateObject<UniformRandomVariable> ();
  double trafStar = trafficStart->GetValue(appStart, appStart + 0.01);
  apps.Start(Seconds(trafStar));
  apps.Stop(Seconds(simulationTime));
}

void StaRxDropTrace (std::string context, Ptr<const Packet> p)
{	
	Ptr<Packet> packet;
	packet = p->Copy();
	if (p->GetSize() == 20)
	{
	  WifiMacHeader hdr;
	  packet->PeekHeader(hdr);
      if (hdr.IsRts())
		colCntSta++; //assume that both packets are dropped
	}
}

void
StaAssocTrace (std::string context, Mac48Address address)
{
	int staId =  atoi(context.c_str());
	totalStasToAss--;
	*assFile << Simulator::Now().GetSeconds () << " Associated STA " << staId << " still: " << totalStasToAss << std::endl;

/*	Ptr<WifiMac> macAp = DynamicCast<WifiNetDevice> (apDevs.Get(staId))->GetMac();
	Ptr<WifiMac> macSta = DynamicCast<WifiNetDevice> (staDevs.Get(staId))->GetMac();
	
	PointerValue ptr;
	macSta->GetAttribute ("BE_EdcaTxopN", ptr);
	Ptr<EdcaTxopN> edcaTxopNSta = ptr.Get<EdcaTxopN> ();
	macAp->GetAttribute ("BE_EdcaTxopN", ptr);
	Ptr<EdcaTxopN> edcaTxopNAp = ptr.Get<EdcaTxopN> ();

	Mac48Address addressSta = macSta->GetAddress();
	Mac48Address addressAp = macAp->GetAddress();
	edcaTxopNAp->SetupBlockAck(0,addressSta,true);
	edcaTxopNSta->SetupBlockAck(0,addressAp,false);	*/
}

void ApRxTrace (std::string context, Ptr<const Packet> p)
{
	int apId = atoi(context.c_str());
	bytesTotalPerAp.at (apId) += p->GetSize();
}

void StaRxTrace (std::string context, Ptr<const Packet> p)
{
	int staId =  atoi(context.c_str());
	bytesTotalPerSta.at (staId) += p->GetSize();
}

void StaTxTrace (std::string context, Ptr<const Packet> p)
{
	int staId =  atoi(context.c_str());
	bytesTotalPerStaTx.at (staId) += p->GetSize();
}

void ApTxTrace (std::string context, Ptr<const Packet> p)
{
    int apId = atoi(context.c_str());
    bytesTotalPerApTx.at (apId) += p->GetSize();
	Ptr<Packet> packet;
	packet = p->Copy();
	if (p->GetSize() == 20)
	{
		WifiMacHeader hdr;   
	    packet->PeekHeader(hdr);
        if (hdr.IsRts())		 
		  transmissionsCnt++;
	}	     
}

void CheckThroughput ()
{
  for (unsigned int i = 0; i < ApsNo; i++)
  {
	  double mbsRx = ((bytesTotalPerAp.at (i) * 8.0) /1000000);
	  bytesTotalPerAp.at (i) = 0;
	  double mbsTx = ((bytesTotalPerApTx.at (i) * 8.0) /1000000);
	  bytesTotalPerApTx.at (i) = 0;

	  *outfileAps << mbsRx << " " << mbsTx << " ";
  }

  *outfileAps<< std::endl;
  
  for (unsigned int i = 0; i < StasNo; i++)
  {
	  double mbsRx = ((bytesTotalPerSta.at (i) * 8.0) /1000000);
	  double mbsTx = ((bytesTotalPerStaTx.at (i) * 8.0) /1000000);
	  bytesTotalPerSta.at (i) = 0;
	  bytesTotalPerStaTx.at (i) = 0;

	  *outfileStas << mbsRx << " " << mbsTx << " ";
  }  
  *outfileStas<< std::endl;
  
  //although traffic starts on the 10th sec (see SelectSrcDestForAp function)
  //we could discard all events measured before that, but still this amount 
  //will have negligible impact!
  if ((uint32_t) (Simulator::Now().GetSeconds()) == (uint32_t) (simulationTime))
  {
	  high_resolution_clock::time_point t2 = high_resolution_clock::now();
	  auto timerT = duration_cast<microseconds>( t2 - t1 ).count();
	  
	  double colProb = (double) colCntSta / (double) transmissionsCnt;
	  *commonCompl << Simulator::GetEventCount() <<" " << timerT << " " << colProb << std::endl;
	  std::cout << "SNR disabled " << disableSnr <<" StasNo "<< StasNo << " ApsNo " << ApsNo << " GenerationRate (Mbps): " << (unsigned int) generationRate / 1e6 << " MCS " << rate << " SimTime (sec): " << simulationTime
				<< " Events (No.): " << Simulator::GetEventCount() << " ExecTime (sec): " << ((double) timerT) /1e6 << " CollProb: " << colProb << std::endl;
  }  

  //check throughput every second
  Simulator::Schedule (Seconds (1.0), &CheckThroughput);
}

  enum DropPolicy
  {
    DROP_NEWEST,
    DROP_OLDEST
  };

int main (int argc, char *argv[])
{
	disableSnr = true;
	StasNo = 50;
	ApsNo = 50;	
	
	generationRate = 120000000;
	rate = 9;
	simulationTime = 50.0;
	
	t1 = high_resolution_clock::now();
	
	//LogComponentEnable ("WifiPhy", LOG_LEVEL_ALL);
	
	CommandLine cmd;
	
	cmd.AddValue ("disableSnr", "disableSnr parameter", disableSnr);
	cmd.AddValue ("StasNo", "StasNo parameter", StasNo);
	cmd.AddValue ("ApsNo", "ApsNo parameter", ApsNo);
	cmd.AddValue ("generationRate", "generationRate parameter", generationRate);
	cmd.AddValue ("rate", "rate parameter", rate);
	cmd.AddValue ("simulationTime", "simulationTime parameter", simulationTime);
	
	cmd.Parse (argc, argv);	
	
	totalStasToAss = StasNo;
	
	Time beaconInterval = MicroSeconds (102400);
	double antennaGain = 0.0;
	double rxNoiseFigure = 4.0; // is found from the for loop below
	double txPower = 20.0;
	double energyDetectionThreshold = -96.0;
	double ccaMode1Threshold = -96.0;
	
	double preemptWinDbm = 100.0;
	
	double frequency = 5e9;
	uint8_t channelNo = 36;
	int channelWidth = 20;
	double shadow = 0;
	uint8_t walls = 10;
	uint8_t floors = 3;	
	int gi = 3200;
	
	uint16_t minCw = 15;
	uint16_t maxCw = 15;
	int ampdu = 64;
	payloadSize = 1458; //1500 byte IP packet
	
	bool dropOldest = true; //drop the latest packet in queue	
	
	
 /* double BOLTZMANN = 1.3803e-23; // thermal noise at 290K in J/s = W
	double Nt = BOLTZMANN * 290.0 * channelWidth * 1e6; // Nt is the power of thermal noise in W
	
    for (unsigned int ii = 0; ii < 100; ii++)
	{
		double noiseFloor = ii * Nt; // receiver noise Floor (W) which accounts for thermal noise and non-idealities of the receiver
		double noiseFloorDbm = 10.0 * std::log10 (noiseFloor * 1000.0);
		std::cout << noiseFloor << " " << noiseFloorDbm << " " << ii << std::endl;
	} */
	
	std::vector<Ssid> bsSsidVector;
		
	uint32_t maxAmpdu = ampdu * (payloadSize + 28 + 20); //payloadSize + 28 + 20
	
    Config::SetDefault("ns3::RegularWifiMac::BE_MaxAmpduSize", UintegerValue (maxAmpdu));
    Config::SetDefault ("ns3::WifiRemoteStationManager::RtsCtsThreshold", UintegerValue (1000));     

	if(dropOldest){
		DropPolicy drpPol = DROP_OLDEST;
		Config::SetDefault("ns3::WifiMacQueue::DropPolicy",  EnumValue (drpPol));
	}
	else{
		DropPolicy drpPol = DROP_NEWEST;
		Config::SetDefault("ns3::WifiMacQueue::DropPolicy",  EnumValue (drpPol));	
	}  
    
    WifiHelper wifi;
    WifiMacHelper wifiMac;
    
    std::ostringstream ctrlRate;
    ctrlRate << "OfdmRate6Mbps";        
    
    YansWifiPhyHelper wifiPhy = YansWifiPhyHelper::Default ();
    Ptr<YansWifiChannelHelper> wifiChannel = CreateObject<YansWifiChannelHelper> ();
    wifiChannel->AddPropagationLoss ("ns3::TgaxSce1PropagationLossModel", 
									 "Frequency", DoubleValue (frequency), 
									 "ShadowingStd", DoubleValue(shadow),
									 "Floors", UintegerValue(floors),
									 "Walls", UintegerValue(walls));
    wifiChannel->SetPropagationDelay ("ns3::ConstantSpeedPropagationDelayModel");  
    wifi.SetStandard (WIFI_PHY_STANDARD_80211ax_5GHZ);   
    
	wifiStaNode.Create (StasNo);
	wifiApNode.Create (ApsNo);    
	packetSocket.Install (wifiStaNode);
	packetSocket.Install (wifiApNode);   
	
	std::ostringstream fileNameAps;
	std::ostringstream fileNameStas;
	std::ostringstream fileNameColl;
	std::ostringstream fileNameAss;
	
	fileNameAps << "Complexity_APs_File_SNR_" << disableSnr << "_Rng_" << RngSeedManager::GetRun() << ".tr";
	fileNameStas << "Complexity_STAs_File_SNR_" << disableSnr << "_Rng_" << RngSeedManager::GetRun() << ".tr";
	fileNameColl << "Complexity_col_File_SNR_" << disableSnr << "_Rng_" << RngSeedManager::GetRun() << ".tr";
	fileNameAss << "Complexity_assoc_File_SNR_" << disableSnr << "_Rng_" << RngSeedManager::GetRun() << ".tr";
	
	std::ofstream outfile1 ((fileNameAps.str()).c_str ());
	outfileAps = &outfile1;	
	std::ofstream outfile2 ((fileNameStas.str()).c_str ());
	outfileStas = &outfile2;
	std::ofstream outfile3 ((fileNameColl.str()).c_str ());		
	commonCompl = &outfile3;
	std::ofstream outfile4 ((fileNameAss.str()).c_str ());		
	assFile = &outfile4;	
    
    Ptr<YansWifiChannel> channelYans = wifiChannel->Create ();
	wifiPhy.SetChannel (channelYans);
	
	Ptr<PropagationLossModel> propagationLoss;
	
	Config::Set ("/NodeList/*/DeviceList/*/$ns3::WifiNetDevice/HeConfiguration/GuardInterval", TimeValue (NanoSeconds (gi)));
	
    std::ostringstream DataRate;
    DataRate << "HeMcs" << rate;
    
    double distance = 0.2;
    std::cout << "Setting APs" << std::endl;
    
	MobilityHelper mobility;
	mobility.SetPositionAllocator ("ns3::GridPositionAllocator",
								 "MinX", DoubleValue (0.0),
								 "MinY", DoubleValue (0.0),
								 "DeltaX", DoubleValue (distance),
								 "DeltaY", DoubleValue (distance),
								 "Z", DoubleValue (2.0),
								 "GridWidth", UintegerValue (10),
								 "LayoutType", StringValue ("RowFirst"));
	mobility.SetMobilityModel ("ns3::ConstantPositionMobilityModel");
	mobility.Install (wifiApNode);	
	        
    for (unsigned int ii = 0; ii < ApsNo; ii++)
    {
		bytesTotalPerAp.push_back (0);
		bytesTotalPerApTx.push_back (0);	
			      
		std::string ssidString ("sr-collaboration");
		std::stringstream ss;
		ss << ii;
		ssidString += ss.str ();
		Ssid ssid = Ssid (ssidString);
		bsSsidVector.push_back(ssid);	
  
        wifi.SetRemoteStationManager ("ns3::ConstantRateWifiManager","DataMode", StringValue (DataRate.str ()), "ControlMode", StringValue (ctrlRate.str ())); 
        wifiMac.SetType ("ns3::ApWifiMac",
						  "BeaconGeneration", BooleanValue (false),
						  "QosSupported", BooleanValue (true),
						  "EnableBeaconJitter", BooleanValue (false),
						  "BeaconInterval", TimeValue (beaconInterval),
						  "Ssid", SsidValue (ssid));	 

       apDevs.Add(wifi.Install (wifiPhy, wifiMac, wifiApNode.Get(ii)));    

       //Ptr<WifiNetDevice> apDevice = DynamicCast<WifiNetDevice> (apDevs.Get(ii));
       //Ptr<WifiRemoteStationManager> rmtMngr = apDevice->GetRemoteStationManager ();

	   Ptr<WifiMac> macAp = DynamicCast<WifiNetDevice> (apDevs.Get(ii))->GetMac();
	   Ptr<WifiPhy> phyAp = DynamicCast<WifiNetDevice> (apDevs.Get(ii))->GetPhy();
       Ptr<ApWifiMac> apMac = DynamicCast<ApWifiMac> (macAp);    
       NS_ASSERT (apMac);
       
       //Modify EDCA configuration
	   PointerValue ptr;
	   Ptr<QosTxop> edca;
	   macAp->GetAttribute ("BE_Txop", ptr);
	   edca = ptr.Get<QosTxop> ();
	   edca->SetMinCw (minCw);
  	   edca->SetMaxCw (maxCw);
   
	   
	   //phyAp->SetAttribute("GuardInterval", TimeValue (NanoSeconds (gi)));
	   phyAp->SetAttribute("ChannelNumber", UintegerValue (channelNo));
	   phyAp->SetAttribute("ChannelWidth",UintegerValue(channelWidth)); 
	   phyAp->SetAttribute("EnergyDetectionThreshold", DoubleValue(energyDetectionThreshold));
	   phyAp->SetAttribute("CcaMode1Threshold", DoubleValue(ccaMode1Threshold));
	   phyAp->SetAttribute("RxNoiseFigure", DoubleValue(rxNoiseFigure));
	   phyAp->SetAttribute("TxGain", DoubleValue (antennaGain));
	   phyAp->SetAttribute("RxGain", DoubleValue (antennaGain));
	   phyAp->SetAttribute("TxPowerStart", DoubleValue (txPower));
	   phyAp->SetAttribute("TxPowerEnd", DoubleValue (txPower)); 
	   phyAp->SetAttribute("DisableSNR", BooleanValue (disableSnr)); 
	   if (preemptWinDbm >= 0.0)
	   {	
			Ptr <SimpleFrameCaptureModel> frameCapture = CreateObject<SimpleFrameCaptureModel> ();
			frameCapture->SetMargin (preemptWinDbm);  
			phyAp->SetAttribute("FrameCaptureModel", PointerValue(frameCapture));	
       }
	   
  	   /*MAC traces*/
	   macAp->TraceConnect ("MacRx", ss.str (), MakeCallback(&ApRxTrace));	 
	   /*PHY traces*/
	   phyAp->TraceConnect ("PhyTxBegin", ss.str (), MakeCallback(&ApTxTrace));
	   
	   Ptr<UniformRandomVariable> beaconStartTime = CreateObject<UniformRandomVariable> ();

	   Simulator::Schedule(Seconds (beaconStartTime->GetValue(0.5, 3.0)),&BeaconStarter, macAp);
	   
	   if (ii == 0)
		 propagationLoss = DynamicCast<YansWifiChannel> (DynamicCast<WifiNetDevice> (apDevs.Get(ii))->GetChannel())->GetPropagationLossModel ();	                              							
	}
	
	std::cout << "Setting STAs" << std::endl;
	
	MobilityHelper mobilitySta;
	mobilitySta.SetPositionAllocator ("ns3::GridPositionAllocator",
								 "MinX", DoubleValue (0.0),
								 "MinY", DoubleValue (0.0),
								 "DeltaX", DoubleValue (distance),
								 "DeltaY", DoubleValue (distance),
								 "Z", DoubleValue (1.0),
								 "GridWidth", UintegerValue (10),
								 "LayoutType", StringValue ("RowFirst"));
	mobilitySta.SetMobilityModel ("ns3::ConstantPositionMobilityModel");
	mobilitySta.Install (wifiStaNode);	
	
    for (unsigned int ii = 0; ii < StasNo; ii++)
    {
		bytesTotalPerSta.push_back (0);
		bytesTotalPerStaTx.push_back(0);
        
        wifi.SetRemoteStationManager ("ns3::ConstantRateWifiManager","DataMode", StringValue (DataRate.str ()), "ControlMode", StringValue (ctrlRate.str ()));
        
        Ptr<UniformRandomVariable> ProbTime = CreateObject<UniformRandomVariable> ();
	    double probTimeOut = ProbTime->GetValue(0.1, 0.5);        
        
		wifiMac.SetType ("ns3::StaWifiMac",
						  "Ssid", SsidValue (bsSsidVector.at(ii)),
						  "ActiveProbing", BooleanValue (true),
						  "QosSupported", BooleanValue (true),
						  "ProbeRequestTimeout", TimeValue (Seconds (probTimeOut)));  
	 		          
	 	staDevs.Add(wifi.Install (wifiPhy, wifiMac, wifiStaNode.Get(ii)));
	 	
		Ptr<WifiMac> macSta = DynamicCast<WifiNetDevice> (staDevs.Get(ii))->GetMac();
		Ptr<WifiPhy> phySta = DynamicCast<WifiNetDevice> (staDevs.Get(ii))->GetPhy();
		Ptr<StaWifiMac> staMac = DynamicCast<StaWifiMac> (macSta);    
        NS_ASSERT (staMac); 		
        
        Ptr<UniformRandomVariable> AssocTime = CreateObject<UniformRandomVariable> ();
	    double assReqTimeOut = AssocTime->GetValue(0.2, 0.6);
	    macSta->SetAttribute("AssocRequestTimeout", TimeValue (Seconds(assReqTimeOut)));           
			 
       //Modify EDCA configuration
	   PointerValue ptrS;
	   Ptr<QosTxop> edcaS;
	   macSta->GetAttribute ("BE_Txop", ptrS);
	   edcaS = ptrS.Get<QosTxop> ();
	   edcaS->SetMinCw (minCw);
	   edcaS->SetMaxCw (maxCw); 	
		
		macSta->SetAttribute("MaxMissedBeacons", UintegerValue (99999));	
		
	   /*if (ii==0)
	    channelNo = 36;
	   else if (ii==1) 
	    channelNo = 116;
	   else
	    channelNo = 165;   		   */
		
		//phySta->SetAttribute("GuardInterval", TimeValue (NanoSeconds (gi)));
	    phySta->SetAttribute("ChannelNumber", UintegerValue (165));
	    phySta->SetAttribute("ChannelWidth",UintegerValue(channelWidth)); 
	    phySta->SetAttribute("EnergyDetectionThreshold", DoubleValue(energyDetectionThreshold));
	    phySta->SetAttribute("CcaMode1Threshold", DoubleValue(ccaMode1Threshold));
	    phySta->SetAttribute("RxNoiseFigure", DoubleValue(rxNoiseFigure));
	    phySta->SetAttribute("TxGain", DoubleValue (antennaGain));
	    phySta->SetAttribute("RxGain", DoubleValue (antennaGain));
	    phySta->SetAttribute("TxPowerStart", DoubleValue (txPower));
	    phySta->SetAttribute("TxPowerEnd", DoubleValue (txPower)); 	
	    phySta->SetAttribute("DisableSNR", BooleanValue (disableSnr));
	    if (preemptWinDbm >= 0.0)
	    {
			Ptr <SimpleFrameCaptureModel> frameCapture = CreateObject<SimpleFrameCaptureModel> ();
			frameCapture->SetMargin (preemptWinDbm); 	    
			phySta->SetAttribute("FrameCaptureModel", PointerValue(frameCapture));	
		}

		std::stringstream ss;
		ss << ii;	    
	    
  	   /*MAC traces*/
	   macSta->TraceConnect ("MacRx", ss.str (), MakeCallback(&StaRxTrace));	
	   macSta->TraceConnect ("Assoc", ss.str (), MakeCallback(&StaAssocTrace));
	   
	   phySta->TraceConnect ("PhyTxBegin", ss.str (), MakeCallback(&StaTxTrace));
	   
	    if (ii == 1)
			phySta->TraceConnect ("PhyRxDrop", ss.str (), MakeCallback(&StaRxDropTrace));	   
	   
	   Ptr<UniformRandomVariable> staStartTime = CreateObject<UniformRandomVariable> ();
	   Simulator::Schedule(Seconds (staStartTime->GetValue(0.50, 7.0)),&ActivateSta, phySta, channelNo);	  
	   SelectSrcDestForAp (wifiApNode.Get (ii), apDevs.Get(ii), wifiStaNode.Get(ii), staDevs.Get(ii));   	       		             
	}	

	CheckThroughput ();
    	
	Simulator::Stop (Seconds (simulationTime + 1));
	Simulator::Run ();
	Simulator::Destroy ();
	
	return 0;
}
